from django.apps import AppConfig


class mentorConfig(AppConfig):
    name = 'mentor'
