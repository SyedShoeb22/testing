# This file makes 'lxp' a Python package

