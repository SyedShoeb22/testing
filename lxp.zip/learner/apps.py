from django.apps import AppConfig


class LearnerConfig(AppConfig):
    name = 'learner'
