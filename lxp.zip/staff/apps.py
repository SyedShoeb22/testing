from django.apps import AppConfig


class staffConfig(AppConfig):
    name = 'staff'
