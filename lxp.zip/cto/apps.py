from django.apps import AppConfig


class ctoConfig(AppConfig):
    name = 'cto'
