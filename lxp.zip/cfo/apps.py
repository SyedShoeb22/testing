from django.apps import AppConfig


class TrainerConfig(AppConfig):
    name = 'cfo'
